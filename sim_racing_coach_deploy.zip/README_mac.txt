Sim Racing Coach - Mac Setup

1. Install dependencies:
   brew install espeak ffmpeg
   pip install streamlit pandas pyttsx3

2. To run the app:
   cd sim_racing_coach_app
   streamlit run sim_racing_dashboard.py

3. Use the sidebar to upload:
   - reference_laps/reference_lap.csv
   - user_sessions/user_lap.csv
